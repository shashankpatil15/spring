package com.assignment.model;

import java.util.Date;

public class Flight {

	private String flightNo;
	private String origin;
	private String destination;
	
	private Date time_depart;
	private Date time_arrive;
	
	private Date date;
	private double amount;
	
	public Flight() {
		// TODO Auto-generated constructor stub
	}
	
	public Flight(String flightNo, String origin, String destination, Date time_depart, Date time_arrive, Date date, double amount) {
		super();
		this.flightNo = flightNo;
		this.origin = origin;
		this.destination = destination;
		this.time_depart = time_depart;
		this.time_arrive = time_arrive;
		this.date = date;
		this.amount = amount;
	}

	
	
	public String getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Date getTime_depart() {
		return time_depart;
	}
	public void setTime_depart(Date time_depart) {
		this.time_depart = time_depart;
	}
	public Date getTime_arrive() {
		return time_arrive;
	}
	public void setTime_arrive(Date time_arrive) {
		this.time_arrive = time_arrive;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}

	
	@Override
	public String toString() {
		return "Flight [flightNo=" + flightNo + ", origin=" + origin + ", destination=" + destination + ", time_depart="
				+ time_depart + ", time_arrive=" + time_arrive + ", date=" + date + ", amount=" + amount + "]";
	}

}
