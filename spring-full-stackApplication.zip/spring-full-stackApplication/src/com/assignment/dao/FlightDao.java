package com.assignment.dao;

import java.util.List;
import com.assignment.model.Flight;

public interface FlightDao
 {
	
	Flight addFlight( Flight flight );
	
	boolean removeFlight(String flightNo);

	Flight getFlight(String flightNo);

	boolean updateFlight(Flight flight);
	
	List<Flight> getAllFlights();
}	
