package com.assignment.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.assignment.data.FlightMap;
import com.assignment.model.Flight;

public class MapFlightDaoImpl  implements FlightDao{
	
	
	public MapFlightDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Flight addFlight(Flight flight) {
		
		FlightMap.INSTANCE.getMap().put(flight.getFlightNo(), flight);
		return flight;
	}

	@Override
	public boolean removeFlight(String flightNo) {
		
		Map<String,Flight> map  = FlightMap.INSTANCE.getMap();
		if(map.containsKey(flightNo)){
			map.remove(flightNo);
		}
		return false;
	}
	
	@Override
	public Flight getFlight(String flightNo) {
		Map<String,Flight> map  = FlightMap.INSTANCE.getMap();
		if(map.containsKey(flightNo)){
			return map.get(flightNo);
		}
		return null;
	}

	
	@Override
	public boolean updateFlight(Flight flight) {
		
		Map<String,Flight> map  = FlightMap.INSTANCE.getMap();
		if(map.containsKey(flight.getFlightNo())){
			map.put(flight.getFlightNo() , flight);
		}
		
		return false;
	}

	@Override
	public List<Flight> getAllFlights() {
		
		// TODO Auto-generated method stub
		return new ArrayList<>(FlightMap.INSTANCE.getMap().values());
	}

	
	
}
