package com.assignment.data;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import com.assignment.model.Flight;

public enum FlightMap {

	INSTANCE;
	private Map<String, Flight> map;
	
	private FlightMap() {
		
		this.map = new HashMap<String,Flight>();	
		try {
			
			// 	public Flight(String flightNo, String origin, String destination, Date time_depart, Date time_arrive, Date date, double amount) {
			SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");			

			Flight flight1 = new Flight("AL-202","kolkata","Mumbai", dateFormater.parse("2017-11-01 08:00:00") , dateFormater.parse("2017-11-01 10:30:00"),dateFormater.parse("2017-11-01 01:02:03"),2300.00);
			Flight flight2 = new Flight("AL-203","Pune","Mumbai", dateFormater.parse("2017-11-01 08:00:00") , dateFormater.parse("2017-11-01 10:30:00"),dateFormater.parse("2017-11-01 01:02:03"),990.00);
			Flight flight3 = new Flight("AL-204","Delhi","Mumbai", dateFormater.parse("2017-11-01 08:00:00") , dateFormater.parse("2017-11-01 10:30:00"),dateFormater.parse("2017-11-01 01:02:03"),850.00);
			Flight flight4 = new Flight("AL-205","Chennai","Mumbai", dateFormater.parse("2017-11-01 08:00:00") , dateFormater.parse("2017-11-01 10:30:00"),dateFormater.parse("2017-11-01 01:02:03"),950.00);
			
			this.map.put(flight1.getFlightNo(), flight1);
			this.map.put(flight2.getFlightNo(), flight2);
			this.map.put(flight3.getFlightNo(), flight3);
			this.map.put(flight4.getFlightNo(), flight4);
			
		}catch(Exception exception) {
			exception.printStackTrace();
		}
	}
	
	
	public Map<String, Flight> getMap() {
		return map;
	}

	
}
