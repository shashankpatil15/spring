package com.assignment.service;

import java.util.List;

import com.assignment.model.Flight;

public interface FlightService {

	Flight addFlight( Flight flight );
	
	boolean removeFlight(String flightNo);

	Flight getFlight(String flightNo);

	boolean updateFlight(Flight flight);
	
	List<Flight> getAllFlights();
	
}

