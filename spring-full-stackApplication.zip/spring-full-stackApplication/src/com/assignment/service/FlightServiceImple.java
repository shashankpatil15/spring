package com.assignment.service;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import com.assignment.dao.FlightDao;
import com.assignment.model.Flight;

public class FlightServiceImple  implements FlightService{
	
	private	FlightDao flightDao;
	
	public FlightServiceImple(FlightDao flightDao) {
		this.flightDao = flightDao;
	}
	
	public FlightDao getFlightDao() {
		return flightDao;
	}
	public void setFlightDao(FlightDao flightDao) {
		this.flightDao = flightDao;
	}
	
	@Override
	public Flight addFlight(Flight flight) {
		return flightDao.addFlight(flight); 
	}

	@Override
	public boolean removeFlight(String flightNo) {
		return flightDao.removeFlight(flightNo); 
	}

	@Override
	public Flight getFlight(String flightNo) {
		return flightDao.getFlight(flightNo); 
	}

	@Override
	public boolean updateFlight(Flight flight) {
		return flightDao.updateFlight(null); 
	}

	@Override
	public List<Flight> getAllFlights() {
		return flightDao.getAllFlights();
	}
	
	
	@PostConstruct
	public void init() {
		System.out.println("EmployeeService Impl initialized...");
	}

	@PreDestroy
	public void destroy() {
		System.out.println("EmployeeService Impl destroyed...");
	}

}
