package com.assignment.presentation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.assignment.model.Flight;
import com.assignment.service.FlightService;

public class SpringFlightApp {

	public SpringFlightApp() {
		// TODO Auto-generated constructor stub
	}

	
	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("beans-flight.xml");

		System.out.println("Spring Container Created....");

		FlightService fs = context.getBean( FlightService.class );

		System.out.println("es:" + fs);

		System.out.println("All Employee details");
		System.out.println("========================");

		for (Flight e : fs.getAllFlights())
			System.out.println(e);
		
		System.out.println("=====================");

		// Close the context
		((ClassPathXmlApplicationContext)context ).close(); 
	}

	
}
