package com.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {

	public HelloController() {
	System.out.println("HEllo Controller created....");
	}

@RequestMapping("/hello")	
public String hello(){
	System.out.println("In ....hello method.....");
	return "hello";
}

}
