package com.controllers;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/greet")	
public class GreetController {

	public GreetController() {
	System.out.println("GreetController created....");
	}



@RequestMapping(method=RequestMethod.GET)	
public ModelAndView hello(){
	System.out.println("In ....greet method.....");
	return new ModelAndView("greet", "today", new Date());
}

@RequestMapping(value="/hi",method=RequestMethod.GET)	
public  @ResponseBody String hi(){
	System.out.println("In ....greet method.....");
	return "Today is "+new Date();
}


}
