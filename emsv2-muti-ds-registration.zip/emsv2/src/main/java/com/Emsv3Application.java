package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

@SpringBootApplication
public class Emsv3Application {

	public Emsv3Application() {
	System.out.println("EmsV3 App Created....");
	}
	
	
	public static void main(String[] args) {
		SpringApplication.run(Emsv3Application.class, args);
	}
	
	
	

	@Bean
    public ServletRegistrationBean spring() {
        
		System.out.println("Spring DS created............");
		
		
		DispatcherServlet dispatcherServlet = new DispatcherServlet();   
      AnnotationConfigWebApplicationContext applicationContext = 
    		  new AnnotationConfigWebApplicationContext();
        
        dispatcherServlet.setApplicationContext(applicationContext);
        
        ServletRegistrationBean servletRegistrationBean = new ServletRegistrationBean(dispatcherServlet, "/spring/*");
        servletRegistrationBean.setName("spring");
        return servletRegistrationBean;
    }
    @Bean
    public ServletRegistrationBean rest() {
    	System.out.println("Rest DS created............");
		
    	DispatcherServlet dispatcherServlet = new DispatcherServlet();
        AnnotationConfigWebApplicationContext applicationContext = new AnnotationConfigWebApplicationContext();
        dispatcherServlet.setApplicationContext(applicationContext);
        ServletRegistrationBean servletRegistrationBean = new ServletRegistrationBean(dispatcherServlet, "/rest/*");
        servletRegistrationBean.setName("rest");
        return servletRegistrationBean;
    }
	
	
	
	
	
}
