package com.pradeep.company.payroll.service;

import java.util.List;

import com.pradeep.company.payroll.model.Employee;

public interface EmployeeService {
	boolean addEmployee(Employee employee);
	Employee getEmployee(int id);
	boolean deleteEmployee(int id);
	boolean updateEmployee(Employee employee);
	List<Employee> getEmployeeList();
	
	
}
