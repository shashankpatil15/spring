package com.pradeep.company.payroll.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pradeep.company.payroll.model.Employee;
import com.pradeep.company.payroll.service.EmployeeService;

@RequestMapping("/semployees")
@Controller
public class EmployeeSpringController {

	
@Autowired	
private EmployeeService es;	
	
public EmployeeSpringController() {
System.out.println("EmployeespringController created....");
}


@RequestMapping(method=RequestMethod.GET)	
public ModelAndView getAllemployees(){
	return new ModelAndView("employeeList", "employees", es.getEmployeeList());
}

@RequestMapping(value="/edit/{id}",method=RequestMethod.GET)	
public String getEmployee(@PathVariable("id") int id,ModelMap map){
    map.addAttribute("employees",es.getEmployeeList()); 
	 map.addAttribute("command",es.getEmployee(id));
	return "editEmployee";
	}

@RequestMapping(value="/new",method=RequestMethod.GET)	
public ModelAndView newEmployee(ModelMap map ){
	map.addAttribute("employees", es.getEmployeeList());
	return new ModelAndView("addEmployee", "command", new Employee());
}

@RequestMapping(value="/delete",method=RequestMethod.GET)	
public ModelAndView deleteEmployee(@RequestParam("id") int id){
	
	es.deleteEmployee(id);
	return new ModelAndView("employeeList", "employees", es.getEmployeeList());
}


@RequestMapping(value="/update",method=RequestMethod.POST)	
public ModelAndView updateEmployee(@ModelAttribute Employee employee){
	System.out.println("In update   :"+employee);
	es.updateEmployee(employee);
	
	return new ModelAndView("employeeList", "employees", es.getEmployeeList());
}


@RequestMapping(value="/add",method=RequestMethod.POST)	
public ModelAndView addEmployee(@ModelAttribute Employee employee){
System.out.println("In addd :"+employee);
	es.addEmployee(employee);
	return new ModelAndView("employeeList", "employees", es.getEmployeeList());
}

	
}
