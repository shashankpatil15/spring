package com.pradeep.company.payroll.service;

public class A {

	public A() {
	System.out.println("A dflt constrcutor created....");
	}
	
}
