package com.pradeep.company.payroll.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pradeep.company.payroll.model.Employee;


@Repository 
public interface EmployeeDao extends JpaRepository<Employee, Integer>{
	
}


/*@Repository
public interface EmployeeDao extends MongoRepository<Employee, Integer>{
	
}
*/
