package com.pradeep.company.payroll.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pradeep.company.payroll.dao.EmployeeDao;
import com.pradeep.company.payroll.model.Employee;

//@Component
@Service
public class EmployeeServiceImpl implements EmployeeService{

	
	@Autowired
	private EmployeeDao employeeDao;
	
	
	
	public EmployeeServiceImpl() {
	System.out.println("EmployeeServiceImpl deflt contrcutor created.....");
	}
	
	
	
	public EmployeeServiceImpl(EmployeeDao employeeDao) {
		super();
		this.employeeDao = employeeDao;
		System.out.println("EmployeeServiceImpl param contrcutor created.....");
}


	public void setEmployeeDao(EmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
		System.out.println("EmployeeServiceImpl setEmployeeDao.....");
	}
	

	@Override
	public boolean addEmployee(Employee employee) {

		
		return employeeDao.save(employee)==employee;
	}

	@Override
	public Employee getEmployee(int id) {
		// TODO Auto-generated method stub
	   Optional<Employee> o=employeeDao.findById(id);
		
		return o.get();
	}

	@Override
	public boolean deleteEmployee(int id) {
		employeeDao.deleteById(id);
		return true;
	}

	@Override
	public boolean updateEmployee(Employee employee) {
			 			
		return employeeDao.save(employee)==employee;
	}

	@Override
	public List<Employee> getEmployeeList() {
		// TODO Auto-generated method stub
		return employeeDao.findAll();
	}

}
