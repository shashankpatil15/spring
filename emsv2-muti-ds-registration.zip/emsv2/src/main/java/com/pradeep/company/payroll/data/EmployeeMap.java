package com.pradeep.company.payroll.data;

import java.util.HashMap;
import java.util.Map;

import com.pradeep.company.payroll.model.Employee;

public enum EmployeeMap {

	INSTANCE;

	private Map<Integer, Employee> map;

	private EmployeeMap() {

		this.map = new HashMap<>();

		Employee e1 = new Employee("Pradeep Chinchole", 12000.00, "Pune");
		Employee e2 = new Employee("Sachin Patil", 72000.00, "Mumbai");
		Employee e3 = new Employee("Mohan Chinchole", 42000.00, "Pune");
		Employee e4 = new Employee("Mahesh Kadam", 32000.00, "Pune");
		Employee e5 = new Employee("Pramod Patil", 32000.00, "Solapur");

		map.put(e1.getId(), e1);
		map.put(e2.getId(), e2);
		map.put(e3.getId(), e3);
		map.put(e4.getId(), e4);
		map.put(e5.getId(), e5);

	}

	public Map<Integer, Employee> getMap() {
		return map;
	}

}
