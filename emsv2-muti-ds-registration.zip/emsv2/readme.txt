
@Controller & @ResponseBody => @RestController



@RequestMApping(value="/hello",method=RequestMethod.GET) => @GetMapping("/hello")
@RequestMApping(value="/hello",method=RequestMethod.POST) => @PutMapping("/hello")
@RequestMApping(value="/hello",method=RequestMethod.DELETE) => @DeleteMapping("/hello")
@RequestMApping(value="/hello",method=RequestMethod.PUT) => @PutMapping("/hello")
@RequestMApping(value="/hello",method=RequestMethod.PATCH) => @PatchMapping("/hello")


@RequestBody => JSON->Java
@ResponseBody ->Java to JSON
================================================
JPA-Hibernate


====================================
           Employee
====================================
Id          Name            Salary
=====================================
101       Pradeep          120000
102       Pramod           220000



class Employee{
private int id;
private String name;
private double salary;

}

Employee e=new Employee();
e.setId(101);
e.setName("Pradeep");
e.setSalary(120000);



CrudRepository
     |
PagingAndSortingRespoitory
     |
JPARepository

          

  
  
  



















                 





