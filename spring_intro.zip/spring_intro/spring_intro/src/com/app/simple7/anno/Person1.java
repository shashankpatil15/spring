package com.app.simple7.anno;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("person1")
public class Person1 implements PersonIntf {
	
	
	@Value("35")
   private Integer age;
	
	@Value("Rama")
   private String name;

	@Override
	public String show() {
		// TODO Auto-generated method stub
		return "Name ="+name+" Age = "+age;
	}

}
