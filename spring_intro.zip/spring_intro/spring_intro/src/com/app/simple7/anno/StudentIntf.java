package com.app.simple7.anno;

public interface StudentIntf {
	String show();
}
