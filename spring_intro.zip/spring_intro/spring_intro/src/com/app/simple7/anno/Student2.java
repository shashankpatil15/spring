package com.app.simple7.anno;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("stud2")
public class Student2 implements StudentIntf{
	
	@Autowired(required=true)
	@Qualifier("person2")
	private PersonIntf person;
	
	@Value("Struts2")
   private String course;
	
	@PostConstruct
	public void myInit()
	{
		System.out.println("in post-con , person = "+person);
	}
	
	@PreDestroy
	public void myDestroy()
	{
		System.out.println("in pre-destroy , person = "+person);
	}
	@Override
	public String show() {
		
		return "Student Dtls "+person.show()+", course=" + course;
				
	}


	
	

  }