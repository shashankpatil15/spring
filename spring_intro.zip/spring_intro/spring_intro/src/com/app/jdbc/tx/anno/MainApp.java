package com.app.jdbc.tx.anno;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
public static void main(String[] args) {
	
ApplicationContext context=new ClassPathXmlApplicationContext("beans-jdbc-tx-anno.xml");
	
	
AccountDao accountDao=(AccountDao)context.getBean("accountDao");

accountDao.transferFund(57, 51,1000.00);

System.out.println("All Accounts\n====================");
for(Account account:accountDao.getAllAccounts())
System.out.println(account);
((ClassPathXmlApplicationContext)context).close();

}
}