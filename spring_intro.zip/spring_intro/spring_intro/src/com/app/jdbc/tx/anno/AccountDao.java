package com.app.jdbc.tx.anno;
import java.util.List;

public interface AccountDao {

	boolean insertAccount(Account account);
	boolean deleteAccount(int accno);
	Account getAccount(int accno);
	boolean withdraw(int accno,double amount);
	boolean deposit(int accno,double amount);
	boolean transferFund(int source,int destination,double amount);
	List<Account> getAllAccounts();
	List<Account> getAllAccountsWithBalanceBetween(double min,double max);
		
	
}
