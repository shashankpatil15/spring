package com.app.jdbc.tx.xml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
public static void main(String[] args) {
	
ApplicationContext context=new ClassPathXmlApplicationContext("beans-jdbc-tx-xml.xml");
	
	
AccountDao accountDao=(AccountDao)context.getBean("accountDao");

accountDao.transferFund(57, 51,20000.00);


((ClassPathXmlApplicationContext)context).close();

}
}