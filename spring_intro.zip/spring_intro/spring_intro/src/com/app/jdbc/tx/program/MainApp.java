package com.app.jdbc.tx.program;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
public static void main(String[] args) {
	
ApplicationContext context=new ClassPathXmlApplicationContext("beans-jdbc-tx-prog.xml");
	
	
AccountDao accountDao=(AccountDao)context.getBean("accountDao");

accountDao.transferFund(51, 57,20000.00);


((ClassPathXmlApplicationContext)context).close();

}
}