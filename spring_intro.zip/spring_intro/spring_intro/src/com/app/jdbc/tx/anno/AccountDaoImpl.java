package com.app.jdbc.tx.anno;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Transactional(propagation=Propagation.REQUIRED)
public class AccountDaoImpl implements AccountDao {

	private JdbcTemplate jdbcTemplate;
		
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	
	
	@Override
	public boolean insertAccount(Account account) {
	
		return jdbcTemplate.update("insert into account values(?,?,?,?)", account.getAccno(), account.getName(),
				account.getBalance(), account.getDob())==1;
	}

	@Override
	public boolean deleteAccount(int accno) {
		
	return 	jdbcTemplate.update("delete from account where accno=?",accno)==1;
			
	}

	
	@Transactional(readOnly=true)
	@Override
	public Account getAccount(int accno) {
	return jdbcTemplate.queryForObject("select * from account where accno=?",Account.class,accno);
	}

	@Override
	public boolean withdraw(int accno, double amount) {
	
		return jdbcTemplate.update("update account set balance=balance-? where accno=?",amount,accno)==1;
					
	}

	@Override
	public boolean deposit(int accno, double amount) {
		
		return jdbcTemplate.update("update account set balance=balance+? where accno=?",amount,accno)==1;
	
	}

	@Transactional(timeout=5)
	@Override
	public boolean transferFund(int source,int destination, double amount) {
	    	withdraw(source, amount);
			System.out.println("Account "+source+" is debited by Rs"+amount+"/-");
			
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			deposit(destination, amount);
			System.out.println("Account "+destination+" is credited by Rs"+amount+"/-");
		
			return true;
	}

	@Transactional(readOnly=true)
	@Override
	public List<Account> getAllAccounts() {
		return jdbcTemplate.query("select * from account", new AccountMapper());
	}
	
	
	
	
    @Transactional(readOnly=true)
	@Override
	public List<Account> getAllAccountsWithBalanceBetween(double min, double max) {

		return jdbcTemplate.query("select * from account where balance between ? and ?", new AccountMapper(), min, max);

	}

}
