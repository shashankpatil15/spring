package com.app.jdbc;

import java.util.Random;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
public static void main(String[] args) {
	
ApplicationContext context=new ClassPathXmlApplicationContext("beans-jdbc.xml");
	
AccountDao accountDao=(AccountDao)context.getBean("accountDao");

/*Random r=new Random();
//Insert three accounts
System.out.println("Insert 4 accounts \n============================");
System.out.println(accountDao.insertAccount(new Account(r.nextInt(100), "pradeep",r.nextDouble()*100000, "2011-11-11")));
System.out.println(accountDao.insertAccount(new Account(r.nextInt(100), "Sunil", r.nextDouble()*100000, "2012-09-11")));
System.out.println(accountDao.insertAccount(new Account(r.nextInt(100), "Mahesh",r.nextDouble()*100000, "2014-11-11")));
System.out.println(accountDao.insertAccount(new Account(r.nextInt(100), "Mahesh",r.nextDouble()*100000, "2014-11-11")));


//display all the records	
System.out.println("Account Details\n===========================");
for(Account account:accountDao.getAllAccounts())
	System.out.println(account);

	


//display all the records	
System.out.println("Account Details\n===========================");
for(Account account:accountDao.getAllAccountsWithBalanceBetween(10000, 50000))
	System.out.println(account);

*/

accountDao.transferFund(25,51, 10000);

}
}