package com.app.jdbc;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

public class AccountDaoImpl1 extends JdbcDaoSupport implements AccountDao  {

	

	@Override
	public boolean insertAccount(Account account) {
	
		return getJdbcTemplate().update("insert into account values(?,?,?,?)", account.getAccno(), account.getName(),
				account.getBalance(), account.getDob())==1;
	}

	@Override
	public boolean deleteAccount(int accno) {
		
	return 	getJdbcTemplate().update("delete from account where accno=?",accno)==1;
			
	}

	@Override
	public Account getAccount(int accno) {
	return getJdbcTemplate().queryForObject("select * from account where accno=?",Account.class,accno);
	}

	
	@Override
	public boolean withdraw(int accno, double amount) {
	
		return getJdbcTemplate().update("update account set balance=balance-? where accno=?",amount,accno)==1;
					
	}

	@Override
	public boolean deposit(int accno, double amount) {
		
		return getJdbcTemplate().update("update account set balance=balance+? where accno=?",amount,accno)==1;
	
	}

	@Override
	public boolean transferFund(int source,int destination, double amount) {
	    
			withdraw(source, amount);
			deposit(destination, amount);
		    
		    return true;
	}

	@Override
	public List<Account> getAllAccounts() {
		return getJdbcTemplate().query("select * from account", new AccountMapper());
	}

	@Override
	public List<Account> getAllAccountsWithBalanceBetween(double min, double max) {

		return getJdbcTemplate().query("select * from account where balance between ? and ?", new AccountMapper(), min, max);

	}

}
