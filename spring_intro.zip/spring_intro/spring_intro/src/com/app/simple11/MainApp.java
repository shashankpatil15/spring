package com.app.simple11;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
   public static void main(String[] args) {
      ConfigurableApplicationContext context = 
      new ClassPathXmlApplicationContext("beans11.xml");

      //  raise a start event.
      //context.start();
	 
      HelloWorld obj = (HelloWorld) context.getBean("helloWorld");

      obj.getMessage();

      //  raise a stop event.
      //context.stop();
   }
}