//simple example which just prints bean name
package com.app.simple2;

import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.BeansException;

public class InitHelloWorld implements BeanPostProcessor {
 
   public Object postProcessBeforeInitialization(Object bean,
                 String beanName) throws BeansException {
      System.out.println("BeforeInitialization : " + beanName);
      return bean;  // you can return any other object as well
   }

   public Object postProcessAfterInitialization(Object bean,
                 String beanName) throws BeansException {
	   
	   ((HelloWorld)bean).setMessage("Modified MEssage");
      System.out.println("AfterInitialization : " + beanName);
      return bean;  // you can return any other object as well
   }

}