package com.app.simple2;

public class HelloWorld {
   private String message;

   public HelloWorld() {
System.out.println("Hello World Bean Created...");
   }
   
   public void setMessage(String message){
	   System.out.println("In setMessage....");
      this.message  = message;
   }
   public void getMessage(){
      System.out.println("Your Message : " + message);
   }
   public void init(){
      System.out.println("Bean is going through init.");
   }
   public void destroy(){
      System.out.println("Bean will get destroyed now.");
   }
}