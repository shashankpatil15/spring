package com.app.simple2;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;

public class MyBeanFacoryPostProcessor implements BeanFactoryPostProcessor{

	public MyBeanFacoryPostProcessor() {
	System.out.println("MBFPP created...");
	}
	
	@Override
	public void postProcessBeanFactory(ConfigurableListableBeanFactory factory) throws BeansException {
	
		System.out.println("MBFPP post Proecess Bean Factory...");
		System.out.println("No of BEans :"+factory.getBeanDefinitionCount());
		System.out.println("No of BEans :"+factory.getSingletonCount());
		
	}
	

}
