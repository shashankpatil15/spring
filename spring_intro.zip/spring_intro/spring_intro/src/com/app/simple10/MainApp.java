package com.app.simple10;

import java.util.Date;
import java.util.Locale;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"beans10.xml");

		String name = context.getMessage("username.required",new Object[] {123,new Date()},Locale.GERMAN);
		System.out.println(name);
		name = context.getMessage("username.required",new Object[] {123,new Date()},Locale.FRANCE);
		System.out.println(name);
		name = context.getMessage("username.required",new Object[] {123,new Date()},Locale.ENGLISH);
		System.out.println(name);
		 name = context.getMessage("username.required",new Object[] {123,new Date()},new Locale("hi", "IN"));
		System.out.println(name);
	


	}

}
