package com.app.simple1;

public class HelloWorld {
	
	 
	private String message;
	
	public HelloWorld() {
		System.out.println("in constr "+getClass().getName() +message);
	}
  

   public void setMessage(String message){
	   System.out.println("in setter");
      this.message  = message;
   }
   public void getMessage(){
      System.out.println("Your Message : " + message);
   }
   public void init1(){
      System.out.println("Bean is going through init."+message);
   }
   public void destroy1(){
      System.out.println("Bean will get destroyed now.");
   }
}