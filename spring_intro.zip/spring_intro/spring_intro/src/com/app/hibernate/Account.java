package com.app.hibernate;

import java.io.Serializable;
import java.sql.Date;

public class Account implements Serializable{
private int accno;
private String name;
private double balance;
private Date dob;

public Account() {
}

public int getAccno() {
	return accno;
}
public void setAccno(int accno) {
	this.accno = accno;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public Date getDob() {
	return dob;
}
public void setDob(Date dob) {
	this.dob = dob;
}
@Override
public String toString() {
	return "Account [accno=" + accno + ", name=" + name + ", balance=" + balance + ", dob=" + dob + "]";
}
public Account(int accno, String name, double balance, String dob) {
	super();
	this.accno = accno;
	this.name = name;
	this.balance = balance;
	this.dob = Date.valueOf(dob);
}
	
}
