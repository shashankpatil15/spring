package com.app.hibernate;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
public static void main(String[] args) {
	
ApplicationContext context=new ClassPathXmlApplicationContext("beans-hibernate.xml");

	
AccountDao accountDao=context.getBean(AccountDao.class);
/*
//Insert three accounts
System.out.println("Insert 3 accounts \n============================");
System.out.println(accountDao.insertAccount(new Account(101, "pradeep", 12000, "2011-11-11")));
System.out.println(accountDao.insertAccount(new Account(102, "Sunil", 15000, "2012-09-11")));
System.out.println(accountDao.insertAccount(new Account(103, "Mahesh", 16000, "2014-11-11")));

*/	

//display all the records	
System.out.println("Account Details\n===========================");
for(Account account:accountDao.getAllAccounts())
	System.out.println(account);

//accountDao.withdraw(72,1000);
accountDao.transferFund(51, 57, 10000);

}
}