package com.app.hibernate.tx.xml;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class AccountDaoImpl implements AccountDao{

private HibernateTemplate  hibernateTemplate;	
	


public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
	this.hibernateTemplate = hibernateTemplate;
}


	@Override
	public boolean insertAccount(Account account) {
          boolean isAccountInserted=false;
          
            hibernateTemplate.save(account);
			
   		
		return  true ;
	}

	@Override
	public boolean deleteAccount(int accno) {
		
		Account account=hibernateTemplate.get(Account.class, 65);
		hibernateTemplate.delete(account);	
		
		System.out.println("Account "+accno+" Deleted...");
			
		
		return true;
	}

	@Override
	public Account getAccount(int accno) {
		return hibernateTemplate.get(Account.class, accno);
	}

	@Override
	public boolean withdraw(int accno, double amount) {
		
		
         Account account=hibernateTemplate.get(Account.class,accno);

		account.setBalance(account.getBalance()-amount);
		
		hibernateTemplate.saveOrUpdate(account);
		
		System.out.println("Account "+accno+" is debited by Rs "+amount);
		return true;
	}

	@Override
	public boolean deposit(int accno, double amount) {
	
		
        Account account=hibernateTemplate.get(Account.class,accno);

		account.setBalance(account.getBalance()+amount);
		
		hibernateTemplate.saveOrUpdate(account);
		
		System.out.println("Account "+accno+" is credited by Rs "+amount);
		return true;
	}

	@Override
	public boolean transferFund(int accno, int destination, double amount) {

		withdraw(accno, amount);
		int a=100/0;
		deposit(destination, amount);
		System.out.println("Fund transfered successfully.........");
		
		return true;
	}

	@Override
	public List<Account> getAllAccounts() {
		return  hibernateTemplate.loadAll(Account.class);
  
	}

	@Override
	public List<Account> getAllAccountsWithBalanceBetween(double min, double max) {
		
		Query query=hibernateTemplate.getSessionFactory()
				                 .openSession()
				                 .createQuery("FROM Account a");
		
		
		System.out.println(query.list().size());
		
		return	new ArrayList<Account>();		     
		
	}

}
