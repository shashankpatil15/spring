package com.app.hibernate.tx.xml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
public static void main(String[] args) {
	
ApplicationContext context=new ClassPathXmlApplicationContext("beans-hibernate-tx-xml.xml");

AccountDao accountDao=context.getBean(AccountDao.class);

accountDao.transferFund(72, 65, 100);
}
}