package com.app.hibernate.tx.anno;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
public static void main(String[] args) {
	
ApplicationContext context=new ClassPathXmlApplicationContext("beans-hibernate-tx-anno.xml");

AccountDao accountDao=context.getBean(AccountDao.class);

accountDao.transferFund(72, 65, 100);


}
}