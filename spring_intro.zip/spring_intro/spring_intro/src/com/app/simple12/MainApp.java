package com.app.simple12;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
	public static void main(String[] args) {
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext(
				"beans12.xml");

		CustomEventPublisher cvp = (CustomEventPublisher) context
				.getBean("customEventPublisher");
		cvp.publish();
	//	cvp.publish();
	}
}