package com.app.spel;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class NumberGuess2 {
	@Value("#{T(java.lang.Math).random() * 10.0}")
	private double randomNumber;
	
	@Value("#{systemProperties['user.home']}")
	private String userHome;

	public double getRandomNumber() {
		return randomNumber;
	}

	
	public String getUserHome() {
		return userHome;
	}

}
