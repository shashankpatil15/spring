package com.app.simple5.autowire;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
   public static void main(String[] args) {
      ApplicationContext context = 
             new ClassPathXmlApplicationContext("beans5-autowire.xml");

      TextEditorSingleSpeller te = (TextEditorSingleSpeller) context.getBean("textEditor");

      te.spellCheck();
   }
}