package com.app.simple5.autowire;

public class TextEditorSingleSpeller {
	private SpellChecker advSpellChecker;

	public SpellChecker getAdvSpellChecker() {
		return advSpellChecker;
	}

	public TextEditorSingleSpeller() {
	System.out.println("TextEditor Deflt constructor...");
	}
	
	public TextEditorSingleSpeller(SpellChecker advSpellChecker) {
		this.advSpellChecker = advSpellChecker;
		System.out.println("In AdvSpeelchecker param.....");
	}

	public void setAdvSpellChecker(SpellChecker advSpellChecker) {
		this.advSpellChecker = advSpellChecker;
		System.out.println("setAdvSpellChecker....");
	}

	public void spellCheck() {

		advSpellChecker.checkSpelling();
	}
}