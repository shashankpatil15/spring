package com.app.simple5.autowire.byname;

public interface SpellChecker {
	void checkSpelling();

}
