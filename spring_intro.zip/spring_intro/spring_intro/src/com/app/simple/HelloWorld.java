package com.app.simple;

public class HelloWorld {
	private String message;

	public HelloWorld() {
		System.out.println("in constr " + getClass().getName());
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void getMessage() {
		System.out.println("Your Message : " + message);
	}
}