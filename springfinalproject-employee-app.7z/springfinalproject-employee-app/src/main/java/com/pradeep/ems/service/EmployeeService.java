package com.pradeep.ems.service;

import java.util.List;

import com.pradeep.ems.model.Employee;

public interface EmployeeService {
	void addEmployee(Employee employee);
	public List<Employee> listEmployeess();
	public List<Employee> listEmployeessBySalaryBetween(double min,double max);
	
	
	public Employee getEmployee(int empid);
	public void deleteEmployee(int empid);
	void updateEmployee(Employee employee);
}