package com.pradeep.ems.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.pradeep.ems.model.Employee;
import com.pradeep.ems.service.EmployeeService;

@RestController
public class EmployeeRestController {

@Autowired	
private EmployeeService employeeService;


public EmployeeRestController() {
System.out.println("EmployeeController Created.........");
}

@GetMapping("/employees")
public List<Employee> employess(){
	return employeeService.listEmployeess();
}


@GetMapping("/employees/filter")
public List<Employee> employessBySalaryBetween(@RequestParam("min")double min,@RequestParam("max")double max){
	return employeeService.listEmployeessBySalaryBetween(min, max);
}

@GetMapping("/employees/{empid}")
public Employee getEmployee(@PathVariable("empid")int empid){
	return employeeService.getEmployee(empid);
	
}


@PostMapping("/employees")
public List<Employee> addEmployee(Employee employee,ModelMap map,BindingResult result){

	return employeeService.listEmployeess();

}



@DeleteMapping("/employees/{empid}")
public List<Employee> deleteEmployee(@PathVariable("empid")int empid){

	employeeService.deleteEmployee(empid);
	return employeeService.listEmployeess();

}

@PutMapping("/employees/{id}")
public List<Employee> updateEmployee(@PathVariable("empid")int empid, @RequestBody Employee employee){

	employeeService.updateEmployee(employee);
	
	return employeeService.listEmployeess();

}


}
