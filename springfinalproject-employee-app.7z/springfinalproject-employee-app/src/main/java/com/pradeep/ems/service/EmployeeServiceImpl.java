package com.pradeep.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pradeep.ems.dao.EmployeeRepository;
import com.pradeep.ems.model.Employee;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService{

	
	@Autowired
	@Qualifier("employeeRepository")
	//@Qualifier("employeeCustom")
	private EmployeeRepository employeeRepository;
	
	public EmployeeServiceImpl() {
	System.out.println("EmployeeServiceImpl Created...");
	}
	
	
	@Override
	public void addEmployee(Employee employee) {
		employeeRepository.save(employee);
		
	}

	@Override
	public List<Employee> listEmployeess() {
			return employeeRepository.findAll() ;
	}

	@Override
	public List<Employee> listEmployeessBySalaryBetween(double min, double max) {
		// TODO Auto-generated method stub
			return employeeRepository.find(min, max) ;
	}

	@Override
	public Employee getEmployee(int empid) {
		return employeeRepository.findOne(empid);
	}

	@Override
	public void deleteEmployee(int empid) {
		employeeRepository.delete(empid);
		
		}

	@Override
	public void updateEmployee(Employee employee) {
	
		Employee e=employeeRepository.findOne(employee.getId());
		
		e=employee;
		
		employeeRepository.save(employee);
		
		
	}

}
