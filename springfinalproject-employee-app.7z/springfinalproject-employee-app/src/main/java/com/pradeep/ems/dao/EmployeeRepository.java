package com.pradeep.ems.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pradeep.ems.model.Employee;

@Repository
public interface EmployeeRepository  extends JpaRepository<Employee, Integer>{
	    
	@Query("SELECT e FROM Employee e WHERE e.salary between :min and :max")
    public List<Employee> find(@Param("min") double min,@Param("max")double max);
	
}
