package com.pradeep.ems.model;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Employee implements Serializable{
	
@Id
@GeneratedValue(strategy = GenerationType.AUTO)	
private int id;

@NotEmpty
private String name;
@Range(min=10000,max=10000)
private double salary;
@Length(min=10,max=10)
private String mobile;

@NotEmpty
@Email
@Length(min = 6, max = 20)
private String email;
@NotNull
@DateTimeFormat(pattern = "dd-MMM-yyyy")
private Date dob;
private static final SimpleDateFormat sdf=new SimpleDateFormat("dd/MMM/yyyy");

public Employee() {
this.id=new Random().nextInt(10000);
}

public Employee(String name, double salary, String mobile, String email, String dob) throws ParseException {
	super();
	this.id=new Random().nextInt(10000);
	this.name = name;
	this.salary = salary;
	this.mobile = mobile;
	this.email = email;
	this.dob = sdf.parse(dob);
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public double getSalary() {
	return salary;
}

public void setSalary(double salary) {
	this.salary = salary;
}

public String getMobile() {
	return mobile;
}

public void setMobile(String mobile) {
	this.mobile = mobile;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public Date getDob() {
	return dob;
}

public void setDob(Date dob) {
	this.dob = dob;
}

@Override
public String toString() {
	return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", mobile=" + mobile + ", email=" + email
			+ ", dob=" + dob + "]";
}



}
