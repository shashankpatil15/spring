package com.pradeep.ems.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.pradeep.ems.model.Employee;

@Repository("employeeCustom")
public interface EmployeeCustomRepository  extends CrudRepository<Employee, Integer>{
	    

    @Query("select e from Employee e where e.salary <= ?")
    public List<Employee> findBySalaryLessThanEqual (long salary);
	
}
