package com.pradeep.banking.presentation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.pradeep.banking.model.Account;
import com.pradeep.banking.service.AccountService;

public class BankingApp {
	
private AccountService accountService;


public void setAccountService(AccountService accountService) {
	this.accountService = accountService;
	System.out.println("BankingApp setAccountService.... ");
	
}

public BankingApp() {
	System.out.println("BankingApp default constructor....... ");}

public BankingApp(AccountService accountService) {
	super();
	this.accountService = accountService;
	System.out.println("BankingApp param constructor...... ");
}


public void addAccount(Account account){

	if(accountService.addAccount(account))
	System.out.println("Account added successfully");
	else
	System.out.println("Problem In Insertion added successfully");
		
}

public void updateAccount(Account account){

	if(accountService.updateAccount(account))
	System.out.println("Account updated successfully");
	else
	System.out.println("Account doesn't exist");
		
}

public void deleteAccount(int accno){

	if(accountService.deleteAccount(accno))
	System.out.println("Account deleted successfully");
	else
	System.out.println("Account doesn't exist");
		
}



public void showAccount(int accno){

	Account account=accountService.getAccount(accno);
	if(account!=null)
	System.out.println("Account  Details\n==================="+account);
	else
	System.out.println("Account doesn't exist");
		
}

public void showAllAccounts(){
	System.out.println("All Account  Details\n===================");
	for(Account a:accountService.getAllAccounts())	
	System.out.println(a);
	
}

public void init(){
	System.out.println("BAnking App is going through initialization");
	
}
public void destroy(){
	System.out.println("BAnking App is going through destruction");
	
}


public static void main(String[] args) {
	
	
	//create container
	ApplicationContext c=
			 new ClassPathXmlApplicationContext("beans.xml");
	
	
	System.out.println("Spring container created....");
	
	BankingApp ba=c.getBean(BankingApp.class);
	
	ba.showAllAccounts();
	
	
	((ClassPathXmlApplicationContext)c).registerShutdownHook();

	
	
	
	
	
}

	
	

}
